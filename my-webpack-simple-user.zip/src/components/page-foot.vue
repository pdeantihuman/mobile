<template>
    <div>
        <em>北京科技大学天津学院 网络中心 V0.1</em>
    </div>
</template>

<script>
    export default {
        name: "page-foot"
    }
</script>

<style scoped>
    div{
        text-align: center;
        padding-bottom: 20px;
    }
</style>