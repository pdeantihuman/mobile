<!--<template>-->
    <!--<div id="for_footer">-->
        <!--<div class="container">-->
            <!--<div class="table-responsive">-->
                <!--<table class="table table-striped table-hover table-bordered">-->
                    <!--<tr v-for="select in selects">-->
                        <!--<td><router-link to="/Content"><span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span>&nbsp;{{select.title}}</router-link></td>-->
                    <!--</tr>-->
                <!--</table>-->
            <!--</div>-->
        <!--</div>-->
    <!--</div>-->
<!--</template>-->

<!--<script>-->//TODO：此页面无用！！！！
    <!--import pageContent from './page-content'-->
    <!--export default {-->
        <!--name: "page-select",-->
        <!--data:function () {-->
            <!--return {-->
                <!--docId:$route.query.id,-->
                <!--selects:[]-->
            <!--}-->
        <!--},-->
        <!--mounted:{-->
            <!--loadData () {-->
                <!--let url = `api/articles/${this.docId}/tree`;-->
                <!--console.log(url);-->
                <!--this.axios.get('api/articles/9/tree')-->
                    <!--.then(response => {-->
                        <!--const data = [-->
                            <!--response.data,-->
                        <!--]-->
                        <!--this.selects = data;-->
                    <!--})-->
                    <!--.catch(error => {-->
                        <!--this.$Message.error('404');-->
                    <!--})-->
            <!--}-->
        <!--},-->
        <!--// mounted:function () {-->
        <!--//     $.ajax({-->
        <!--//         url:"http://localhost/select.php?",-->
        <!--//         type:"GET",-->
        <!--//         dataType:"json",-->
        <!--//         success:function (msg) {-->
        <!--//             for (let i in msg){-->
        <!--//                 let a = { message:msg[i]};-->
        <!--//                 this.selects.push(a);-->
        <!--//             }-->
        <!--//         }.bind(this)-->
        <!--//     });-->
        <!--//     this.$emit('sendText','请选择一个故障问题');-->
        <!--// },-->
        <!--components:{-->
            <!--pageContent-->
        <!--}-->
    <!--}-->
<!--</script>-->

<!--<style scoped>-->

<!--</style>-->