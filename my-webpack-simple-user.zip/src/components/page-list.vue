<template>
    <div id="for_footer">
            <div class="container">
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered">
                        <tr v-for="item in items">
                            <td><router-link :to="{ path:'/Content',query:{id:item.id}}"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;{{item.title}}</router-link></td>
                        </tr>
                    </table>
                </div>
            </div>
    </div>
</template>


<script>
    export default {
        name: "page-list",
        data:function(){
            return {
                items:[]
            }
        },
        // mounted:function () {
        //     $.ajax({
        //         url:"http://localhost/list.php?",
        //         type:"GET",
        //         dataType:"json",
        //         success:function (msg) {
        //             for(let i in msg){
        //                 let a = { message : msg[i]};
        //                 this.items.push(a);
        //             }
        //         }.bind(this)
        //     });
        //     this.$emit('sendText','请选择一个帮助文档');//在mounted阶段利用$emit()触发了自定义事件“sendText”
        // }
        mounted(){
            this.axios.get("http://10.1.38.20/api/articles?onlyRoot=1")
                .then(response => {
                    let data = response.data.data;                         //const:常量 let:局部变量 var:全局变量   三种变量
                    // this.item = data[0].title;                               //传递后端参数
                    for (let i=0;i<data.length;i++){
                        this.items.push(data[i]);
                    }
                    console.log(this.items);//得到的数据是对象数组
                    this.$emit('sendText','请选择一个帮助文档');//在mounted阶段利用$emit()触发了自定义事件“sendText”
                });
        },
    }
</script>

<style scoped>

</style>