<template>
    <div id="for_footer">
        <div class="container">
            <div class="row">
                <div class="alert alert-success">{{node.title}}</div><!--TODO:此处数据由数据库查询得来，存储在localstorage-->
            </div>
            <div class="row" id="button">
                <button class="btn btn-default" v-on:click="selectLeft">解决</button>
                <button class="btn btn-default" v-on:click="selectRight">未解决</button>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "page-content",
        data(){
            return{
                tree:[],//整个树的数据
                node:'',//当前显示的节点
            }
        },
        mounted:function () {
                this.$emit('sendText','请查看该方法是否解决您的问题？');
                let url = `api/articles/${this.docId}/tree`;
                console.log(url);
                this.axios.get('api/articles/9/tree')
                    .then(response => {
                        const data = [
                            response.data,
                        ]
                        console.log(data);
                        this.tree = data;
                        this.node = data[0];
                        console.log(this.node);
                    })
                    .catch(error => {
                        this.$Message.error('404');
                    })
            },
        methods:{
            selectLeft:function () {//点击解决按钮触发的事件
                if (this.node.children[0]===undefined){
                    this.$Message.error('这是最后的解决方案了...');
                } else {
                    this.node = this.node.children[0];
                }
            },
            selectRight:function () {//点击为解决按钮触发的事件
                if (this.node.children[1]===undefined){
                    this.$Message.error('这是最后的解决方案了...');
                } else {
                    this.node = this.node.children[1];
                }
            },
        }
    }
</script>

<style scoped>
    #button{
        text-align: center;
    }
</style>